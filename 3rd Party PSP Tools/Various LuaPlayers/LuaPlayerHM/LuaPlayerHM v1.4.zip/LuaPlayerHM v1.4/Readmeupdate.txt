 __    __  __    __    ____  __      __   _  _  ____  ____    _   _  __  __ 
(  )  (  )(  )  /__\  (  _ \(  )    /__\ ( \/ )( ___)(  _ \  ( )_( )(  \/  )
 )(__  )(__)(  /(__)\  )___/ )(__  /(__)\ \  /  )__)  )   /   ) _ (  )    ( 
(____)(______)(__)(__)(__)  (____)(__)(__)(__) (____)(_)\_)  (_) (_)(_/\/\_)

			   LuaPlayerv4.0 WIFI EDITION
-----Important----

PLEASE SEND BACK MORE MORE INFO ON NEW FEATURES WANTED TO QJ FORUMS.


-----Install-----
copy the Lua Player HM v4.0 into your folder for Lua programing and run from xmb.
EASY!

------New Features------
Added WIFI Abiltiy to the player. You can select and add new wireless networks
Wlan.init()
Wlan.term()
Included test file	

Can Run Eboot.pbp files now from lua code.(May not always work)

Fixed Mount and unmount flash and UMD's.(Sometimes didnot work)

Show what LuaPlayerHM version it is.

Slim and Phat Enabled.

------Next Release-----
Alow for acsess to download of internet.
Maybe Ad-Hoc.

------Functions-------
Sound Files able to be played
.aa3
.oma
.omg
.mp3
.ogg
all old sound files from other Luaplayers.

Aa3me functions #####This is the Media Engine Functions####
aa3me.load()
aa3me.play()
aa3me.Stop()
aa3me.eos()    (EndOfStream)
aa3me.getTime()
aa3me.percent()
aa3me.pause()

Mp3me functions #####This is the Media Engine Functions####
Mp3me.load()
Mp3me.play()
Mp3me.Stop()
Mp3me.eos()    (EndOfStream)
Mp3me.getTime()
Mp3me.percent()
Mp3me.pause()

Mp3 functions  #####This is the CPU Functions####
Mp3.load()
Mp3.Stop()
Mp3.pause()
Mp3.play()
Mp3.EndOfStream()
Mp3.getTime()
Mp3.volume()

Ogg functions #####This is the CPU Functions####
Ogg.load()
Ogg.stop()
Ogg.pause()
Ogg.play()
Ogg.EndOfStream()
Ogg.getSec()
Ogg.getMin()
Ogg.getHour()
Ogg.volume()


System functions
System.currentDirectory()
System.listDirectory()
System.createDirectory()
System.removeDirectory()
System.removeFile()
System.rename()
System.usbDiskModeActivate()
System.usbDiskModeDeactivate()
System.powerIsPowerOnline()
System.powerIsBatteryExist()
System.powerIsBatteryCharging()
System.powerGetBatteryChargingStatus()
System.powerIsLowBattery()
System.powerGetBatteryLifePercent()
System.powerGetBatteryLifeTime()
System.powerGetBatteryTemp()
System.powerGetBatteryVolt()
System.powerTick()
System.md5sum()
System.sioInit()
System.sioRead()
System.sioWrite()
System.irdaInit()
System.irdaRead()
System.irdaWrite()
System.sleep()
System.getFreeMemory()
System.Quit()
System.setLow()
System.setReg()
System.setHigh()
System.setcpuspeed() in brackets enter the cpu speed 10-333Mhz
System.madeby() Show the Lua Player version eg luaver = System.madeby()
System.runeboot() Runs an eboot file
System.unassign() unassigns the flash or disk
System.assign() assigns the flash or disk
System.memclean() cleans the ram of unsued code aka frees up memory
System.oaenable() enables the use of Sound functions eg Sound.load() and Sound.play() Voice.play()
System.oadisable() disables the use of Sound functions eg Sound.load() and Sound.play() Voice.play()

Wlan.init() Enables the Wireless and lets you select the newwork
Wlan.term() Disables the Wireless.


And Special Thankx to sakya for the Media engine help and source.
Thx to FaT3oYCG for the help, Codeveloper (functions),
sg57 for the flash assign functions
and Insert_Witty_Name for netdialog in sdk.

Made By HOMEMISTER
	