Included is

The function list for luaplayerhm 6.5
	Includes full functions and examples
	Includes list of new functions and fixes 

LuaplayerHM6.5 Eboot.pbp

LuaplayerHM6.5 webbrowser.PBP
	Alows you to browse the web. You do not need to start Wlan.init()
	To use just load using System.runeboot("path of webbrowser") 
	It will automaticaly return to LuaPlayerHM6.5 if in the same directory as the LuaPlayerHM eboot.pbp *A must*.

Update to the LuaPlayerHM tester.
	Includes new Updater thanks to Khatharr

Regards
The LuaPlayerHM Team
PiCkDaT and Homemister

Thx to all that contribute at the LuaPlayer form and feedback on bugs and requests. Keep up the good work.
