white = Color.new(255, 255, 255)
black = Color.new(0, 0, 0)
green = Color.new(0, 255, 0)

dofile("./system/osk.lua")

OSKeyB_xpos = 10
OSKeyB_ypos = 230

OSKeyB_Init(OSKeyB_xpos, OSKeyB_ypos)

Message_X = 2
Message_Y = 2

messages = Image.createEmpty(460, 210)
messages:clear(black)

started = 0

oldpad = Controls.read()

while true do

pad = Controls.read()

screen:clear(white)

-- insert your main code here

screen:blit(10, 10, messages)

OSKeyB_Start(OSKeyB_xpos, OSKeyB_ypos)

screen:print(110, 230, "Press R to Send the Current Message")
screen:print(110, 240, "Message:")
screen:print(110, 250, text)

Adhoc_state = 1
if started == 0 then
	messages:print(Message_X, Message_Y, "Messenger By homemister Thx to F@T3oYCG", green)
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "Press Select to Initialize the Adhoc", green)
	Message_Y = Message_Y + 10
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "Controlls:", green)
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "D-Pad = On Screen Keyboard Movement", green)
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "Triangle = Change Character Set", green)
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "Square = Delete a Character", green)
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "Cross = Select the Highlighted Character", green)
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "L = Clear the Messages Box", green)
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "R = Send Message", green)
	Message_Y = Message_Y + 10
	messages:print(Message_X, Message_Y, "Start = Quit", green)
	Message_Y = Message_Y + 10
	Message_Y = Message_Y + 10
	started = 1
	end

if Adhoc_state ~= 0 then

	if pad:r() and not oldpad:r() then
		System.message(text,0)
		System.sleep(50)
		text = ""
	end
	if pad:start() and not oldpad:start() then
		dofile("./system/system2.lua")
	end

end

-- insert your main code here

oldpad = pad

screen.flip()
screen.waitVblankStart()

end
