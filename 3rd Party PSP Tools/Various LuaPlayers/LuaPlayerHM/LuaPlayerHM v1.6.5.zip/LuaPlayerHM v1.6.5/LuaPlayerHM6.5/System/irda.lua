-- IrDA sample
System.irdaInit()
ownCrossPressed = false
otherCrossPressed = false
red = Color.new(255, 0, 0)
white = Color.new(255, 255, 255)
timeout = 10
while true do
	screen:clear()
	screen:print(200,100,"hello",white)
	command = System.irdaRead()
	screen:print(100,100,command,white)
	screen:flip()
	screen.waitVblankStart()
	pad = Controls.read()
		if pad:start() then
			dofile("./system/system2.lua")
		end
end
