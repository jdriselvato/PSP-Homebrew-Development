silver = Color.new(192,192,192)
red = Color.new(255,0,0)
green = Color.new(0, 255, 0)
blue = Color.new(0, 0, 255)
black = Color.new(0, 0, 0)
white = Color.new(255, 255, 255)
gray = Color.new(128, 128, 128)
cyan = Color.new(100, 255, 255)


val = 0
oldpad = Controls.read()

logo = Image.createEmpty(128, 64)
logo:clear(gray)
logo:print(20, 20, "LuaPlayer", black)
logo:print(10, 40, "   HM    ", black)

cube = {
	{0, 0, red, -1, -1,  1},  -- 0
	{2, 0, red, -1,  1,  1},  -- 4
	{2, 2, red,  1,  1,  1},  -- 5

	{0, 0, red, -1, -1,  1},  -- 0
	{2, 2, red,  1,  1,  1},  -- 5
	{0, 2, red,  1, -1,  1},  -- 1

	{0, 0, red, -1, -1, -1},  -- 3
	{2, 0, red,  1, -1, -1},  -- 2
	{2, 2, red,  1,  1, -1},  -- 6

	{0, 0, red, -1, -1, -1},  -- 3
	{2, 2, red,  1,  1, -1},  -- 6
	{0, 2, red, -1,  1, -1},  -- 7

	{0, 0, green,  1, -1, -1},  -- 0
	{2, 0, green,  1, -1,  1},  -- 3
	{2, 2, green,  1,  1,  1},  -- 7

	{0, 0, green,  1, -1, -1},  -- 0
	{2, 2, green,  1,  1,  1},  -- 7
	{0, 2, green,  1,  1, -1},  -- 4

	{0, 0, green, -1, -1, -1},  -- 0
	{2, 0, green, -1,  1, -1},  -- 3
	{2, 2, green, -1,  1,  1},  -- 7

	{0, 0, green, -1, -1, -1},  -- 0
	{2, 2, green, -1,  1,  1},  -- 7
	{0, 2, green, -1, -1,  1},  -- 4

	{0, 0, blue, -1,  1, -1},  -- 0
	{2, 0, blue,  1,  1, -1},  -- 1
	{2, 2, blue,  1,  1,  1},  -- 2

	{0, 0, blue, -1,  1, -1},  -- 0
	{2, 2, blue,  1,  1,  1},  -- 2
	{0, 2, blue, -1,  1,  1},  -- 3

	{0, 0, blue, -1, -1, -1},  -- 4
	{2, 0, blue, -1, -1,  1},  -- 7
	{2, 2, blue,  1, -1,  1},  -- 6

	{0, 0, blue, -1, -1, -1},  -- 4
	{2, 2, blue,  1, -1,  1},  -- 6
	{0, 2, blue,  1, -1, -1},  -- 5
}

plane = {
	{blue, -8, -3,  0},
	{cyan, 8,  3,  0},
	{blue,  8,  -3,  0},
	{cyan, 8, 3,  0},
	{blue, -8,  -3,  0},
	{cyan,  -8,  3,  0},
}
macadd = Adhoc.getMac()
nickname = System.nickName()
System.sleep(100)
usb = true
sysver = System.playerVer()
cfwver = System.cfwVersion()
model = System.getModel(0)
devid = "ms0:"
mssize = System.getDevSize(devid)
mssize = (mssize/1024)
mssize = (mssize/1024)
dev = 5
while true do
	screen:clear()
	Gu.start3d()

	-- clear screen
	Gu.clearDepth(0);
	Gu.clear(Gu.COLOR_BUFFER_BIT+Gu.DEPTH_BUFFER_BIT)

	-- setup projection and view matrices

	Gum.matrixMode(Gu.PROJECTION)
	Gum.loadIdentity()
	Gum.perspective(75, 16/9, 0.5, 1000)

	Gum.matrixMode(Gu.VIEW)
	Gum.loadIdentity()

	-- setup matrix for triangle
	Gum.matrixMode(Gu.MODEL)
	Gum.loadIdentity()
	Gum.translate(0, 0, -3);

	-- draw triangle without texture

	Gu.disable(Gu.TEXTURE_2D)
	Gum.drawArray(Gu.TRIANGLES, Gu.COLOR_8888+Gu.VERTEX_32BITF+Gu.TRANSFORM_3D, plane)

	-- setup texture

	Gu.enable(Gu.BLEND)
	Gu.blendFunc(Gu.ADD, Gu.SRC_ALPHA, Gu.ONE_MINUS_SRC_ALPHA, 0, 0)
	Gu.enable(Gu.TEXTURE_2D);
	Gu.texImage(logo)
	Gu.texFunc(Gu.TFX_MODULATE, Gu.TCC_RGBA)
	Gu.texEnvColor(white)
	Gu.texFilter(Gu.LINEAR, Gu.LINEAR)
	Gu.texScale(1, 1)
	Gu.texOffset(0, 0)
	Gu.ambientColor(white)

	-- setup matrix for cube

	Gum.matrixMode(Gu.MODEL)
	Gum.loadIdentity()
	Gum.translate(0, 0, -3.5);
	Gum.rotateXYZ(val * 0.79 * (Gu.PI/180), val * 0.98 * (Gu.PI/180.0), val * 1.32 * (Gu.PI/180.0))

	-- draw cube

	Gum.drawArray(Gu.TRIANGLES, Gu.TEXTURE_32BITF+Gu.COLOR_8888+Gu.VERTEX_32BITF+Gu.TRANSFORM_3D, cube)

	Gu.end3d()

	val = val + 1.34 
	hour = System.getTime(1) 
	min = System.getTime(2) 
	sec = System.getTime(3)
	pmam = System.getTime(5)
	year = System.getDate(1) 
	month = System.getDate(2) 
	day = System.getDate(3) 
	screen:print(110,10,"LuaPlayer HM Wifi Tester",white)
	screen:print(1,30,"press Triagle for Wifi Test",red)
	screen:print(1,50,"press Square for Ad-Hoc Test",red)
	screen:print(1,70,"press Circle for LuaPlayer Version",red)
	screen:print(1,90,"Select to cycle Device free space",red)
	screen:print(1,110,"press L to Test Message",red)
	screen:print(1,130,"press R to Usb function",red)
	screen:print(1,150,"Up to Suspend the PSP",red)
	screen:print(1,170,"Down to Shutdown the PSP",red)
	screen:print(1,190,"Left to Test Eboot.pbp Mp3me and ISO",red)
	screen:print(1,210,"Right to Test UMD GAME",red)
	screen:print(230,230,"Nickname is "..nickname,red)
	screen:print(230,250,"Macaddress "..macadd,red)
	screen:print(1,250,"LuaPlayerHM Ver "..sysver,red)
	screen:print(1,230,"CFW Firmware Ver "..cfwver,red)
	screen:print(230,210,"PSP Type "..model,red)
	screen:print(350,190,System.usbState(3,1),red)
	screen:print(260,170,devid.." "..mssize.." Mb",red)
	screen:print(260,150,hour..":"..min..":"..sec.." "..pmam.." Date: "..year.."/"..month.."/"..day,red)
	screen:print(260,130,"Start to rip UMD to ISO",red)

	pad = Controls.read()
	if pad:select() and not oldpad:select() then
		dev = dev + 1
		if dev == 2 then
			devid = "flash1:"
			mssize = System.getDevSize(devid)
			mssize = (mssize/1024)
			mssize = (mssize/1024)
		end
		if dev == 3 then
			devid = "flash2:"
			mssize = System.getDevSize(devid)
			mssize = (mssize/1024)
			mssize = (mssize/1024)
		end
		if dev == 4 then
			devid = "flash3:"
			mssize = System.getDevSize(devid)
			mssize = (mssize/1024)
			mssize = (mssize/1024)
		end
		if dev == 5 then
			devid = "ms0:"
			mssize = System.getDevSize(devid)
			mssize = (mssize/1024)
			mssize = (mssize/1024)
		end
		if dev == 6 then
			devid = "Ram"
			mssize = System.getFreeMemory()
			mssize = (mssize/1024)
			mssize = (mssize/1024)
		end
		if dev == 7 then
			isok = UMD.checkDisk()
			if isok == 1 then
			devid = "disk0:"
			mssize = UMD.getSize()
			mssize = (mssize/1024)
			mssize = (mssize/1024)
			end
			if isok == 0 then
				dev = 8
			end
		end
		if dev == 8 then
			devid = "VRam"
			mssize = System.getVram()
			mssize = (mssize/1024)
			mssize = (mssize/1024)
		end
		if dev > 8 then
			dev = 1
		end
		if dev == 1 then
			devid = "flash0:"
			mssize = System.getDevSize(devid)
			mssize = (mssize/1024)
			mssize = (mssize/1024)
		end
	end
	if pad:start() and not oldpad:start() then
	--score = 200
	--score = tostring(score)
	--System.startGameSave("Alex","Alex save","Lol it worked",score)
	--System.sleep(300)
	--data = System.startGameLoad()
	--System.sleep(300)
	--System.runeboot("ms0:/PSP/GAME380/LUAPLAYERHM6/webbrowser.PBP")
	--dofile("./System/irda.lua")
	isok = UMD.checkDisk()
	if isok==1 then
		nameiso = System.startOSK("ms0:/ISO/*.ISO","Delete * and Enter ISO name")
		umdsize = UMD.getSize()
		mssize = System.getDevSize("ms0:")
		if mssize > umdsize then
			UMD.ripISO(nameiso)
		else
			System.message("Not enought space on Memory Stick",0)
		end
	else
		System.message("No UMD disk Present",0)
	end
	end
	if pad:r() then
		System.message(usbstat.."Enable Yes, Disable No",1)
		butpress = System.buttonPressed(1)
		if butpress == "yes" then
			System.usbDiskModeActivate()
			usb = false
			usbstat = "  Currently Enabled\n"
		end
		if butpress == "no" then
			System.usbDiskModeDeactivate()
			usb = false
			usbstat = "  Currently Disabled\n"
		end
	end
	if pad:l() then
		txtmsg = System.startOSK("Enter Name","Enter Name")
		System.message(txtmsg,0)
	end
	if pad:triangle() then
		Wlan.init()
		dofile("./System/update.lua")
	end
	if pad:square() then
		screen:clear()
		screen:flip()
		screen:clear()
		screen:flip()
		Adhoc.init()
		dofile("./System/connectadhoc.lua")
	end
	if pad:circle() then
		System.madeby(0)
	end
	if pad:up() then
		System.suspend()
	end
	if pad:down() then
		System.shutdown()
	end
	if pad:right() then
		System.startUMD()
	end
	if pad:left() then
		dofile("./system/filebrowse.lua")
	end

	
	screen.flip()
	screen.waitVblankStart()
	oldpad = pad
end
