white = Color.new(255,255,255)
red = Color.new(255,0,0)
green = Color.new(0, 255,0)
blue = Color.new(0, 0, 255)
black = Color.new(0, 0, 0)

characters = { string.char(97), string.char(98), string.char(99), string.char(100), string.char(101), string.char(102), string.char(103), string.char(104), string.char(105), string.char(106), string.char(107), string.char(108), string.char(109), string.char(110), string.char(111), string.char(112), string.char(113), string.char(114), string.char(115), string.char(116), string.char(117), string.char(118), string.char(119), string.char(120), string.char(121), string.char(122), string.char(32) } 
symbols1 = { string.char(96), string.char(124), string.char(48), string.char(49), string.char(50), string.char(51), string.char(52), string.char(53), string.char(54), string.char(55), string.char(56), string.char(57), string.char(45), string.char(61), string.char(91), string.char(93), string.char(59), string.char(39), string.char(35), string.char(92), string.char(44), string.char(47), string.char(127), string.char(8), string.char(9), string.char(28), string.char(32) }
symbols2 = { string.char(33), string.char(34), "�", string.char(36), string.char(37), string.char(94), string.char(38), string.char(42), string.char(40), string.char(41), string.char(95), string.char(43), string.char(123), string.char(125), string.char(58), string.char(64), string.char(126), string.char(22), string.char(60), string.char(62), string.char(63), "", "", "", "", "", string.char(32) }

-- initiate all of the keyboards start variables
function OSKeyB_Init(xpos, ypos)

mode = 1

current_character = 1

text = ""

current_width = 0
current_height = -10
current_row = -9

currentX = xpos + 1
currentY = ypos + 1

end

-- draw the keyboard
function OSKeyB_Start(xpos, ypos, background_colour, selector_colour, text_colour)

if background_colour == nil then
background_colour = black
end

if selector_colour == nil then
selector_colour = blue
end

if text_colour == nil then
text_colour = green
end

bg = Image.createEmpty(92, 32)
selector = Image.createEmpty(10,10) 

bg:clear(background_colour)
selector:clear(selector_colour)

screen:blit(xpos, ypos, bg)
screen:blit(currentX,currentY, selector)

char_X = xpos - 7
char_Y = ypos + 2

for a = 1, 3 do
current_width = 0
current_height = current_height + 10
current_row = current_row + 9
for b = 1, 9 do
current_width = current_width + 10
if mode == 1 then
screen:print(char_X + current_width, char_Y + current_height, characters[b + current_row], text_colour)
elseif mode == 2 then
screen:print(char_X + current_width, char_Y + current_height, string.upper(characters[b + current_row]), text_colour)
elseif mode == 3 then
screen:print(char_X + current_width, char_Y + current_height, symbols1[b + current_row], text_colour)
elseif mode == 4 then
screen:print(char_X + current_width, char_Y + current_height, symbols2[b + current_row], text_colour)
end
end
end


-- add a character
if pad:cross() and oldpad:cross() ~= pad:cross() then
if mode == 1 then
text = text .. characters[current_character]
elseif mode == 2 then
text = text .. string.upper(characters[current_character])
elseif mode == 3 then
text = text .. symbols1[current_character]
elseif mode == 4 then
text = text .. symbols2[current_character]
end
end

-- delete character
if pad:square() and oldpad:square() ~= pad:square() then
text = string.sub(text, 1, string.len(text) - 1)
end

-- mode 1 to 4
if pad:triangle() and oldpad:triangle() ~= pad:triangle() then
mode = mode + 1
if mode > 4 then
mode = 1
end
end

-- move selector right one 
if pad:right() and oldpad:right() ~= pad:right() and current_character ~= 9 and current_character ~= 18 and current_character ~= 27 then
current_character = current_character + 1
currentX = currentX + 10
elseif pad:right() and oldpad:right() ~= pad:right() then
if current_character == 9 or current_character == 18 or current_character == 27 then
current_character = current_character - 8
currentX = xpos + 1
end
end

-- move selector left one
if pad:left() and oldpad:left() ~= pad:left() and current_character ~= 1 and current_character ~= 10 and current_character ~= 19 then
current_character = current_character - 1
currentX = currentX - 10
elseif pad:left() and oldpad:left() ~= pad:left() then
if current_character == 1 or current_character == 10 or current_character == 19 then
current_character = current_character+ 8
currentX = xpos + 81
end
end

-- move selector down one
if pad:down() and oldpad:down() ~= pad:down() and current_character < 19 then
current_character = current_character + 9
currentY = currentY + 10
elseif pad:down() and oldpad:down() ~= pad:down() and current_character > 18 then
current_character = current_character - 18
currentY = ypos + 1
end

-- move selector up one
if pad:up() and oldpad:up() ~= pad:up() and current_character > 9 then
current_character = current_character - 9
currentY = currentY - 10
elseif pad:up() and oldpad:up() ~= pad:up() and current_character < 18 then
current_character = current_character + 18
currentY = ypos + 21
end



current_width = 0
current_height = -10
current_row = -9

end