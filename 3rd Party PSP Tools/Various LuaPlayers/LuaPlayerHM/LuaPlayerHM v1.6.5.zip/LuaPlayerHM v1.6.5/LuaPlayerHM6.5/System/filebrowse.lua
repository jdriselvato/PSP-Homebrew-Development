-- EVILMANA.COM PSP LUA CODEBASE
-- www.evilmana.com/tutorials/codebase
-- Browse Files
-- SUBMITTED BY: TacticalPenguin
playing = "Stopped"
System.currentDirectory("ms0:/")
white = Color.new(255,255,255)
red = Color.new(255,0,0)
fbrowser = {s = 1, fl = System.listDirectory("ms0:/"),ls = 1, sp = 10}

fbrowser.nf = table.getn(fbrowser.fl)
oldpad = Controls.read()

function runfbrowser()

for i = ((fbrowser.ls-1)*fbrowser.sp)+1, fbrowser.ls*fbrowser.sp do
if fbrowser.nf >= i then
screen:print(0,((i-((fbrowser.ls-1)*fbrowser.sp))*10)-10,
fbrowser.fl[i].name,white)
elseif fbrowser.nf < i then break end
end

screen:print(0,((fbrowser.s-((fbrowser.ls-1)*fbrowser.sp))*10)-10,
fbrowser.fl[fbrowser.s].name,red)

if pad:down() and not oldpad:down() then fbrowser.s = fbrowser.s + 1 end
if pad:up() and not oldpad:up() then fbrowser.s = fbrowser.s - 1 end

if fbrowser.s > fbrowser.nf then fbrowser.s = fbrowser.nf elseif fbrowser.s < 1 then fbrowser.s = 1 end
if fbrowser.s > fbrowser.sp*fbrowser.ls then fbrowser.ls = fbrowser.ls + 1
elseif fbrowser.s < ((fbrowser.ls-1) * fbrowser.sp)+1 then fbrowser.ls = fbrowser.ls - 1 fbrowser.s = (fbrowser.ls)*fbrowser.sp end

if pad:cross() and not oldpad:cross() then
if not fbrowser.fl[fbrowser.s].directory then
if string.lower(string.sub(fbrowser.fl[fbrowser.s].name, -4)) == ".pbp" or string.lower(string.sub(fbrowser.fl[fbrowser.s].name, -4)) == ".PBP" then
ebootdir = System.currentDirectory()
System.runeboot(ebootdir.."/"..fbrowser.fl[fbrowser.s].name)

elseif string.lower(string.sub(fbrowser.fl[fbrowser.s].name, -4)) == ".prx" or string.lower(string.sub(fbrowser.fl[fbrowser.s].name, -4)) == ".PRX" then
prxdir = System.currentDirectory()
System.loadPrx(prxdir.."/"..fbrowser.fl[fbrowser.s].name)

elseif string.lower(string.sub(fbrowser.fl[fbrowser.s].name, -4)) == ".iso" or string.lower(string.sub(fbrowser.fl[fbrowser.s].name, -4)) == ".ISO" then
isodir = System.currentDirectory()
System.startISO(isodir.."/"..fbrowser.fl[fbrowser.s].name)

elseif string.lower(string.sub(fbrowser.fl[fbrowser.s].name, -4)) == ".mp3" then
mp3dir = System.currentDirectory()
Mp3me.load(fbrowser.fl[fbrowser.s].name)
Mp3me.play()
playing = "Playing"
end
elseif fbrowser.fl[fbrowser.s].directory then
System.currentDirectory(fbrowser.fl[fbrowser.s].name)
fbrowser.s = 1
fbrowser.fl=System.listDirectory()
fbrowser.nf=table.getn(fbrowser.fl)
fbrowser.ls = 1
end

elseif pad:triangle() and not oldpad:triangle() then
if System.currentDirectory ~= "ms0:/" then
System.currentDirectory("./..")
fbrowser.s = 1
fbrowser.fl=System.listDirectory()
fbrowser.nf=table.getn(fbrowser.fl)
fbrowser.ls = 1
end
end
end

while true do
pad = Controls.read()
screen:clear()
runfbrowser()
if pad:circle() and not oldpad:circle() then
	Mp3me.stop()
	playing = "Stopped"
end
if pad:square() and not oldpad:square() then
	if pause == true then
		Mp3me.pause()
		playing = "Playing"
		pause = false
	else
		Mp3me.pause()
		playing = "Paused"
		pause = true
	end
end
screen:print(300,10,playing,white)
screen.waitVblankStart()
screen.flip()
oldpad = pad
if pad:start() then break end
if pad:select() then
isok = UMD.checkDisk()
		if isok == 1 then
			disk = UMD.getSize()
			ms = System.getDevSize("ms0:")
			if disk < ms then
				isoname = System.startOSK("ms0:/ISO/*.ISO","Enter Name and Path")
				if isoname ~= "" then
					UMD.ripISO(isoname)
				end
			else
				System.message("UMD size is too big for the Memory Stick\nNot Ripping UMD",0)
			end
		end
end
end
