usbstat = "  Currently Disabled\n"
dofile("./system/system2.lua")
